NF01048 Inteligencia Artificial (2024/2) - Turma A
Alunos: Luis Filipe Rodrigues 314848 - Tiago Elias Steinke 171884 - Juan Dos Santos Arcari 279460

TRABALHO 3 - BUSCA EM GRAFOS
Resultados:

Estado "2_3541687"

BFS:

    Nós expandidos: 220777
    Tempo: 1.824s
    Custo: 23

DFS

    Nós expandidos: 296226
    Tempo: 1.588s
    Custo: 96453

A* Hamming

    Nós expandidos: 20313
    Tempo: 0.465s
    Custo: 23

A* Manhattan

    Nós expandidos: 1524
    Tempo: 0.173s
    Custo: 23
